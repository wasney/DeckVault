### DeckVault v1.1.0-beta.2 (Beta Pre-Release)

> **Beta Testing Build:** Official users on `v1.0.4` stay on the stable release unless they opt into **Enable Beta / Pre-release updates** under **Settings**.

#### What's New
- **Full-Suite Offline Deck Compression (Self-Contained per Deck):**
  - **Smart WebP Image Conversion:** Converts PNG/JPG graphics to WebP (preserving transparency) with optional resolution caps (`2048px` Balanced / `1440px` Compact) and transparent serving by `LocalDeckServer` (zero HTML/JS breakage).
  - **Hardware-Accelerated Video Compression:** Uses Android Jetpack Media3 Transformer (`MediaCodec` H.264/AAC) to shrink oversized embedded `.mp4`/`.mov` clips down to mobile-friendly 1080p/720p bitrates—keeping the original automatically if a clip doesn't shrink by at least 10%.
  - **Transparent On-Disk GZIP:** Compresses HTML, CSS, JS, JSON, and SVG files as `.gz` on disk and streams them directly with `Content-Encoding: gzip` for fast loading.
- **Safe Testing Mode (Optimize as Copy):** Optimizing any existing deck defaults to **Keep original (create compressed copy)** so you can test compressed decks side-by-side without risking or re-downloading your originals.
- **Per-Deck Storage Breakdown:** Tap **More → Storage Info** on any deck to see exact MB used by Videos, Images, PDFs, Text/Code, and Other files.
- **Official vs. Beta Channel Support & Build Fix:** Fixed Kotlin compilation in `DeckOptimizationService` and restricted GitHub Actions triggers to `.zip` uploads only.
